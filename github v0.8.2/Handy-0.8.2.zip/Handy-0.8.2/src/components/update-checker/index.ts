export { default } from "./UpdateChecker";
